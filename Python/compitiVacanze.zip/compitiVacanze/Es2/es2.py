import random

def generate_mac():
    print("%02x:%02x:%02x:%02x:%02x:%02x" % (
            random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255),
            ))

def main():
    generate_mac()

if __name__ == "__main__":
    main()